__name__ = "gerryfair"
__version__ = "0.1.0"

from gerryfair import model, clean, fairness_plots, heatmap
