import numpy as np
import pandas as pd
import pickle
import itertools
import sklearn
from sklearn.linear_model import LogisticRegression
import os
import time
import argparse
import utils 
import importlib
from pandas.api.types import CategoricalDtype
from sklearn import preprocessing

def calc_frontier(method, params_combs, metrics, log=True):
    frontier = [] 
    print("frontier1")
    for i,params in enumerate(utils.product_dicts(params_combs)):
        time1=time.time()
        learner = method(**params)
        if learner.name in ['Plugin', 'WERM']:
        ########################################################
            #m_tr_Xp = tr_gerry_Xp
            #m_test_Xp = test_gerry_Xp 
            m_tr_Xp = tr_Xp 
            m_test_Xp = test_Xp 
        ###########################################################    
        if learner.name == 'GerryFair':
            m_tr_Xp = tr_Xp 
            m_test_Xp = test_Xp 
            
        learner.train(tr_X, m_tr_Xp, tr_y)
        train_time = time.time() - time1
        
        time1=time.time()
        train_preds = learner.predict(tr_X, m_tr_Xp)
        preds = learner.predict(test_X, m_test_Xp)
        predict_time = time.time()-time1

        point_dict = {'method': learner.name, 'params': params}
        metric_dict = {'train_time': train_time, 'predict_time': predict_time}
        for metric_name, metric in exp_metrics:
            metric_dict['train_'+metric_name] = metric(train_preds, tr_X, m_tr_Xp, tr_y)
            metric_dict[metric_name] = metric(preds, test_X, m_test_Xp, test_y)
        point_dict['metrics'] = metric_dict 
        if log:
            print("======================================================================================================")
            print(f"{i}th param set for {learner.name} done, train time: {train_time:.5f}, predict_time: {predict_time:.5f}")
            for metric_name, metric in exp_metrics:
                print(f"train_{metric_name}: {metric_dict['train_'+metric_name]:.7f}, {metric_name}: {metric_dict[metric_name]:.7f}")
        frontier.append(point_dict)
    return frontier

def average_dicts(dicts):
    avg_dict = {}
    keys = dicts[0].keys()
    n = len(dicts)
    for key in keys:
        avg_dict[key] = np.mean([dict_[key] for dict_ in dicts])
    return avg_dict

def average_frontiers(frontiers_list):
    avg_frontiers = []
    matched_frontiers = zip(*frontiers_list)
    for matched_frontier_list in matched_frontiers: 
        frontier = []
        matched_points = zip(*matched_frontier_list)
        for matched_point in matched_points:
            expd = matched_point[0] 
            point_dict = {'method': expd['method'], 'params': expd['params']}
            point_dict['metrics'] = average_dicts([pd['metrics'] for pd in matched_point])
            frontier.append(point_dict)
        avg_frontiers.append(frontier)
    return avg_frontiers


#example usage: python3 train_script.py --expfile ind_exp --dataset german --expname german_ind --ntrials 10
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--expfile', type=str)
    parser.add_argument('--dataset', type=str)
    parser.add_argument('--expname', type=str)
    parser.add_argument('--ntrials', type=int)
    args = parser.parse_args()

    expfile = importlib.import_module(f"experiments.{args.expfile}")
    print("Dataset:", args.dataset)
    
     #i commented
    #with open(f'dataset/{args.dataset}.pkl', 'rb') as f:
    #    X, Xp, y, proatts = pickle.load(f)
    df = pd.read_csv('dataset/adult_final.csv')

    mapping = {'<=50k': 0, '>50k': 1}


    df = df.replace({'14': mapping})


    item = list(df['1'].unique())
    
    cat_type = CategoricalDtype(categories=item, ordered=True)
    df['1'] = df['1'].astype(cat_type).cat.codes

    item = list(df['6'].unique())
    cat_type = CategoricalDtype(categories=item, ordered=True)
    df['6'] = df['6'].astype(cat_type).cat.codes

    item = list(df['13'].unique())
    cat_type = CategoricalDtype(categories=item, ordered=True)
    df['13'] = df['13'].astype(cat_type).cat.codes

    df['3'] = df['3'].astype(CategoricalDtype(categories=df['3'].unique(), ordered=True)).cat.codes
    df['5'] = df['5'].astype(CategoricalDtype(categories=df['5'].unique(), ordered=True)).cat.codes
    df['7'] = df['7'].astype(CategoricalDtype(categories=df['7'].unique(), ordered=True)).cat.codes
    df['8'] = df['8'].astype(CategoricalDtype(categories=df['8'].unique(), ordered=True)).cat.codes
    df['9'] = df['9'].astype(CategoricalDtype(categories=df['9'].unique(), ordered=True)).cat.codes
    #  race sex
    Xp1=df[['8','9']]
    X1= df[['0','1','2','3','5','6','7','10','11','12','13']]
    y1=df['14']
    #df=df.drop(columns=[4,8,9])
    
    proatts=['8','9']
    
    X2=X1.values
    min_max_scaler = preprocessing.MinMaxScaler()
    X= min_max_scaler.fit_transform(X2)
    #print(X.shape[0],X1.shape[1])
    #print(X[0,:])
    
    Xp2 = pd.get_dummies(Xp1, columns=['9','8'], prefix =['s','r'])
    sensitive2=Xp2.values
    y=y1.values
    
    
    ########################################################
    

    sensitive1 = np.zeros((sensitive2.shape[0],10),dtype=int)
#sensitive2 = np.zeros((sens.shape[0],7),dtype=int)
    sensitive3 = np.zeros((sensitive2.shape[0],17),dtype=int)

   #print(sensitive1.shape[0])
   #print(sensitive1.shape[1])
    
    '''
    for k in range(sens.shape[0]):
        for i in range(7):
            sensitive2[k][i] = sens.iloc[k,i]
    '''
    for k in range(sensitive2.shape[0]):
        count = 0
        for i in range(2):
            for j in range(5):
               if sensitive2[k][i]==1 and sensitive2[k][2+j]==1:
                   sensitive1[k][count] = 1
                   count = count+1
               else:
                   sensitive1[k][count] = 0
                   count = count+1
                
    selected = []          
    counts = []
    sensitive3 = np.concatenate((sensitive1,sensitive2), axis = 1)   
    Xp=sensitive3[:,[0, 1, 2, 5, 6, 7, 10, 11, 12, 13, 14, 15, 16]]
    
    '''           
    for i in range(10):
        count = 0
         for k in range(sens.shape[0]):   
                if sensitive1[k][i] == 1:
                 count = count+1    
        counts.append(count)    
    '''    
        

            
    
    ###########################################################
    '''
       
    from numpy import asarray
    from sklearn.preprocessing import OrdinalEncoder
    # define data
    #data = asarray([['red'], ['green'], ['blue']])
    #print(data)
    # define ordinal encoding
    encoder = OrdinalEncoder()
    # transform data
    result = encoder.fit_transform(Xp1)
    print(result)
    
    Xp=result
    
    print(Xp.shape[0],Xp.shape[1])
    y=y1.values
    '''
    
    '''
    print(X)
    print(Xp)
    print(y)
    print(proatts)
    print(X.shape)
    print(Xp.shape)
    print(y.shape)
    print(len(proatts))
    '''
    
    
    
    
    
    
    
    y = y.astype(int)
    # at the end code averaging everything up boi
    # add method.name
    # add metrics to expfile
    print(Xp.shape[0],Xp.shape[1])
    #gerry_Xp = utils.int_gerry(Xp)
    #print(gerry_Xp.shape[0],gerry_Xp.shape[1])
    total_frontiers = []
    
    for trial in range(args.ntrials):
        #gerry_Xp = utils.int_gerry(Xp)
        #print(gerry_Xp)      
        m = Xp.shape[1]
        #(tr_X, tr_Xp, tr_y), (test_X, test_Xp, test_y) = utils.tr_test_split(X, np.hstack((Xp, gerry_Xp)), y)
        (tr_X, tr_Xp, tr_y), (test_X, test_Xp, test_y) = utils.tr_test_split(X, Xp, y)
        tr_gerry_Xp = tr_Xp[:,m:]
        test_gerry_Xp = test_Xp[:,m:]
        tr_Xp = tr_Xp[:,:m]
        test_Xp = test_Xp[:,:m]
        frontiers = []
        for method, params_combs, exp_metrics in zip(expfile.methods, expfile.params_list, expfile.metrics_list):
            frontiers.append(calc_frontier(method, params_combs, exp_metrics))
        total_frontiers.append(frontiers)
        
    average_frontiers = average_frontiers(total_frontiers)


    if not os.path.exists('results'):
        os.makedirs('results')

    with open(f'results/{args.expname}.pkl', 'wb') as f:
        pickle.dump(average_frontiers, f)
  
